#include "DELAY.H"

void delay(int xms)
{
	int i,j;
	for(i=xms;i>0;i--)
		for(j=110;j>0;j--);
}