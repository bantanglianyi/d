#ifndef _CKP_H_
#define _CKP_H_

//#include "CONFIG.H"
//#include "REG51.H"
//#include "STDIO.H"

void	UART1_TxByte(unsigned char dat);
void PrintString1(char  *puts);
char putchar(char c);
void	uart1_init(void);


#endif